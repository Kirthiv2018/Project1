package com.TestCases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.BaseClass_TestNG;

public class TC03_Testng_dataprovider extends BaseClass_TestNG{
	
	@DataProvider (name = "login-data-provider")
	public Object[][] loginmethod(){
		return new Object[][] {{"Admin","admin123"}};
	}
	//,{"Admin","admin1234"}

	@Test (dataProvider = "login-data-provider")
	public void login(String username , String pwd) throws Exception {
			
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.findElement(By.name("username")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(pwd);
    	driver.findElement(By.xpath("//button[@type='submit']")).click();
    	
    	//driver.findElement(By.linkText("PIM")).click();
    	List<WebElement> links = driver.findElements(By.tagName("a"));
        for(WebElement link: links) {
            //printing all the links
            //System.out.println(link.getText() + "-" + link.getAttribute("href"));

            //clicking all links
            link.click();
        }
    	
	}
	

}
