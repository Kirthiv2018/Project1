package com.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC01_FirstScript {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.google.com");
		
		driver.quit(); 
		
		WebDriverManager.edgedriver().setup();
		driver= new EdgeDriver();
		
		driver.get("https://www.google.com");
		
		driver.quit();
		
		
	}

}
